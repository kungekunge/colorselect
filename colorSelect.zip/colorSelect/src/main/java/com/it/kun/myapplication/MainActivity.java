package com.it.kun.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.it.kun.myapplication.javabean.ColorPickerView;

public class MainActivity extends AppCompatActivity {

    private TextView redred;
    private ColorPickerView colorPickerView;
    private TextView greengreen;
    private TextView blueblue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
    }

    private void initView() {
        colorPickerView = (ColorPickerView) findViewById(R.id.color_picker);
        redred = (TextView) findViewById(R.id.textviewRed);
        greengreen = (TextView) findViewById(R.id.textviewGreen);
        blueblue = (TextView) findViewById(R.id.textviewBlue);
    }

    private void initData() {
        colorPickerView.setColorChangedListener(new ColorPickerView.onColorChangedListener() {
            @Override
            public void colorChanged(int red, int blue, int green) {
                redred.setText("red = " + red);
                greengreen.setText("green = " + green);
                blueblue.setText("blue = " + blue);
            }
        });
    }
}
